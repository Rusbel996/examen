//Jugador 1=X; Jugador 2=O
var ultimoJugador = "1";
const listadoBtn = document.querySelectorAll(".btnTresEnRalla");


function marcarJugada(btn) {
    if (!btn.innerHTML) {
        btn.innerHTML = obtenerMarca();
        comprobar();
    }
}

function obtenerMarca() {
    var resultado = "";
    if (ultimoJugador == "1") {
        resultado = "X";
        ultimoJugador = "2";
    } else {
        resultado = "O";
        ultimoJugador = "1";
    }
    return resultado;
}

function verificarResultado() {

}


var pWin = [[0, 1, 2], [3, 4, 5], [6, 7, 8],
[0, 3, 6], [1, 4, 7], [2, 5, 8],
[0, 4, 8], [2, 4, 6]
];

function comprobar() {
    var mensaje = "";
    for (var j = 0; j < pWin.length; j++) {
        if (listadoBtn[pWin[j][0]].innerHTML === "X" && listadoBtn[pWin[j][1]].innerHTML === "X" && listadoBtn[pWin[j][2]].innerHTML === "X") {
            mensaje = "X Gana";
        } else if (listadoBtn[pWin[j][0]].innerHTML === "O" && listadoBtn[pWin[j][1]].innerHTML === "O" && listadoBtn[pWin[j][2]].innerHTML === "O") {
            mensaje = "X Gana";
        } else if (listadoBtn[0].innerHTML != "" && listadoBtn[1].innerHTML != "" && listadoBtn[2].innerHTML != "" && listadoBtn[3].innerHTML !== "" && listadoBtn[4].innerHTML != "" && listadoBtn[5].innerHTML != "" && listadoBtn[6].innerHTML != "" && listadoBtn[7].innerHTML != "" && listadoBtn[8].innerHTML != "") {
            mensaje = "Empate";
            return false;
        }
    }
    if (mensaje) {        
        var listadoBotones = document.getElementsByClassName("btnTresEnRalla");
        for (var i = 0; i < listadoBotones.length; i++) {
            listadoBotones[i].disabled = true;
        }        
        alert(mensaje);
    }

}